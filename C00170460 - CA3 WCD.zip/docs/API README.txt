1.	GET /table/list
2.	GET /table/post/<table>
•	Where table is the name of the table from a given database schema
3.	POST /table/post/<table>
•	Where table is the name of the table from a given database schema
4.	GET /table/showall/<table>
•	Where table is the name of the table from a given database schema
5.	GET /table/showone/<table>/<uri>
•	Where table is the name of the table from a given database schema
•	Where URL is the unique HREF for accessing an individual row


