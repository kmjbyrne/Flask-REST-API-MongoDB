# assignment_two
Assignment Two for PB. RESTful API for MySQL / Collection+JSON message passing
